<?php

Route::get('/', 'ShopController@index')->name('shop.index');
Route::get('/book', 'ShopController@index')->name('shop.index');
Route::get('/book/{product}', 'ShopController@show')->name('shop.show');


Route::get('/thankyou', 'ConfirmationController@index')->name('confirmation.index');


Route::group(['prefix' => 'admin'], function () {
    Voyager::routes();
});

Auth::routes();

Route::get('/home', 'ShopController@index')->name('shop.index');

