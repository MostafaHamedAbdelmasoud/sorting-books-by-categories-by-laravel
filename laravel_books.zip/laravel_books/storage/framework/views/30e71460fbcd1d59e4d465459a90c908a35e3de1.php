<footer style="background-color:#09c;">
    <div class="footer-content container" >
        <div class="made-with">Made with <i class="fa fa-heart heart"></i> by Mostafa Hamed</div>
        <?php echo e(menu('footer', 'partials.menus.footer')); ?>

    </div> <!-- end footer-content -->
</footer>
