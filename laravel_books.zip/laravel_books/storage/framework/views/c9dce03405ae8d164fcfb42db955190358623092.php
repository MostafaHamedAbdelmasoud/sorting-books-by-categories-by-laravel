<div class="might-like-section">
    <div class="container">
        <h2>You can also read...</h2>
        <div class="might-like-grid">
            <?php $__currentLoopData = $mightAlsoLike; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <a href="<?php echo e(route('shop.show', $product->slug)); ?>" class="might-like-product">
                    <img style="height:200px;width:250px;" src="<?php echo e(productImage($product->image)); ?>" alt="book">
                    <div class="might-like-product-name"><?php echo e($product->name); ?></div>
                    <div class="might-like-product-star"><?php echo e(number_format($product->presentStar(), 2)); ?>/5<span style="color:orange;"> <i class="fas fa-star"></i></span></div>
                </a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </div>
    </div>
</div>
