<div class="might-like-section">
    <div class="container">
        <h2>You can also read...</h2>
        <div class="might-like-grid">
            @foreach ($mightAlsoLike as $product)
                <a href="{{ route('shop.show', $product->slug) }}" class="might-like-product">
                    <img style="height:200px;width:250px;" src="{{ productImage($product->image) }}" alt="book">
                    <div class="might-like-product-name">{{ $product->name }}</div>
                    <div class="might-like-product-star">{{ number_format($product->presentStar(), 2) }}/5<span style="color:orange;"> <i class="fas fa-star"></i></span></div>
                </a>
            @endforeach

        </div>
    </div>
</div>
